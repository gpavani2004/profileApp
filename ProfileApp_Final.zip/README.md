# ProfileApp

An Android application created as part of the internship assignment. This app displays a user's profile with information such as credit score, cashback, rewards, and support section. The UI is based on the provided design screenshot.

## 📱 Screenshots

_Add your screenshots in the `screenshots/` folder and display them here using markdown._

Example:
```
![Profile Screen](screenshots/profile_screen.png)
```

## 🚀 How to Run

1. Clone or download this repository.
2. Open the project in **VS Code** or **Android Studio**.
3. Make sure Android SDK and emulator/device are set up.
4. Run `./gradlew build` to build the project.
5. Run `./gradlew installDebug` to install on a connected device/emulator.

## 🛠 Technologies Used

- Java
- Android SDK
- XML (UI Layouts)

## 🧑‍💻 Author

Andaz Kumar (based on the assignment requirement)